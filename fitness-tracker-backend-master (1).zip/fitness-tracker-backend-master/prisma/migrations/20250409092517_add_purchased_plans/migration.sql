-- AlterTable
ALTER TABLE `profile` ADD COLUMN `purchase_plans` JSON NULL;
