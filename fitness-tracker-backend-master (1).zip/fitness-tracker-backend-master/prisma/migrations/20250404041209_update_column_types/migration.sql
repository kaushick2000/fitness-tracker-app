-- AlterTable
ALTER TABLE `profile` MODIFY `photo` TEXT NULL,
    MODIFY `exercise_history` TEXT NULL,
    MODIFY `progress` TEXT NULL,
    MODIFY `nutrition` TEXT NULL,
    MODIFY `active_plan` TEXT NULL;
